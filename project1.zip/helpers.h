#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>

SDL_Surface *load_surface(char const *path);